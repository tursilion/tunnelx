20030217

This was a game for the OnHandPC that Marriseri and I collaborated on for some contest back in the day. I think we did well...!

I'm not exactly sure how to build this anymore, it's probably best as reference.
