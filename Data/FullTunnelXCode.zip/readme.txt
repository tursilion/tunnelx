Tunnel X was original conceived by Maurizo Terzo, who posted an open request on the OnHandPC
message board for anyone interested in working with him. He posted artwork, GIF animations,
and ideas.

Tursi of Harmlesslion.com accepted the challenge, and the two of them have produced this
game for the OnHandPC watch by Matsucom.

The concept is simple - fly your ship through the warp gates home, avoiding meteors and
enemies. There are 10 stages.

Stage 5 is a bonus stage, where you must collect as many coins as possible to boost your score.

After level 5, watch for power up icons which will change all enemies onscreen into coins for
a brief period of time!

Pass level 9, and you'll be treated to a nice ending animation!
